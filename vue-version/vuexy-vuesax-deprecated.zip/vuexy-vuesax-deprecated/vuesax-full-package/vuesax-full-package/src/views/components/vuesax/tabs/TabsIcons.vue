<!-- =========================================================================================
    File Name: TabsIcons.vue
    Description: Display Tabs with Icons
    ----------------------------------------------------------------------------------------
    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template
    Author: Pixinvent
    Author URL: http://www.themeforest.net/user/pixinvent
========================================================================================== -->


<template>
  <vx-card title="Icons" code-toggler>
    <vs-tabs>
      <vs-tab label="Home" icon-pack="feather" icon="icon-home">
      </vs-tab>
      <vs-tab label="Box" icon-pack="feather" icon="icon-box">
      </vs-tab>
      <vs-tab label="Mail" icon-pack="feather" icon="icon-mail">
      </vs-tab>
      <vs-tab label="Heart" icon-pack="feather" icon="icon-heart">
      </vs-tab>
    </vs-tabs>

    <template slot="codeContainer">
&lt;template lang=&quot;html&quot;&gt;
  &lt;vs-tabs&gt;
    &lt;vs-tab label=&quot;Home&quot; icon-pack=&quot;feather&quot; icon=&quot;icon-home&quot;&gt;
    &lt;/vs-tab&gt;
    &lt;vs-tab label=&quot;Box&quot; icon-pack=&quot;feather&quot; icon=&quot;icon-box&quot;&gt;
    &lt;/vs-tab&gt;
    &lt;vs-tab label=&quot;Mail&quot; icon-pack=&quot;feather&quot; icon=&quot;icon-mail&quot;&gt;
    &lt;/vs-tab&gt;
    &lt;vs-tab label=&quot;Heart&quot; icon-pack=&quot;feather&quot; icon=&quot;icon-heart&quot;&gt;
    &lt;/vs-tab&gt;
  &lt;/vs-tabs&gt;
&lt;/template&gt;
    </template>
  </vx-card>
</template>
